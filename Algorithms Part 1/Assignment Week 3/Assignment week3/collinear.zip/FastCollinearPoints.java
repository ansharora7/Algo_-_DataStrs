import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;
import java.util.Arrays;

public class FastCollinearPoints {
    private ArrayList<LineSegment> deal = new ArrayList<>();
    private ArrayList<Point> f1 = new ArrayList<>();
    private LineSegment segs[];
    private ArrayList<Double> ans;
    private ArrayList<Double> end;
    private int line_segs = 0;

    public FastCollinearPoints(Point[] points) // finds all line segments containing 4 or more points
    {
        if (points == null) throw new IllegalArgumentException();
        for (Point p : points)
            if (p == null) throw new IllegalArgumentException();

        Arrays.sort(points);
        //for (Point d : points) System.out.print(d);
        //System.out.println();
        //end = new ArrayList<>();
        for (int i = 0; i < points.length; i++) {
            end = new ArrayList<>();
            ans = new ArrayList<>();
            for (int j = i + 1; j < points.length; j++) {
                Double slope = points[j].slopeTo(points[i]);
                //System.out.println(slope);
                if (slope != Double.NEGATIVE_INFINITY) {
                    //System.out.println(points[j] + " " + points[i] + " Points");
                    ans.add(slope);
                } else throw new IllegalArgumentException();

            }
            //  for (double sl : ans) System.out.print(sl + "  ");
            //System.out.println();
            // end = new ArrayList<>();
            int index = 0;
            for (int s = 0; s < ans.size(); s++) {
                int total = 0;
                if (!end.contains(ans.get(s))) {
                    //      System.out.println(ans.get(s) + " CHECK");
                    for (int k = s + 1; k < ans.size(); k++) {
                        if (ans.get(s).equals(ans.get(k))) {
                            total += 1;
                            index = k;
                        }


                    }
                    //    System.out.println(index + " INDEX");
                    //  System.out.println(total + " TOTAL");
                }

                end.add(ans.get(s));

                if (total >= 2 && !f1.contains(points[index + i + 1])) {
                    deal.add(new LineSegment(points[i], points[index + i + 1]));
                    // System.out.println("YES");
                    line_segs += 1;
                    f1.add(points[index + i + 1]);
                }
            }
        }
    }
    //for (LineSegment s : segs) {
    //System.out.println(s);


    public int numberOfSegments()        // the number of line segments
    {
        return (line_segs);
    }


    public LineSegment[] segments()                // the line segments
    {

        segs = new LineSegment[line_segs];
        for (LineSegment s : deal) {
            if (s != null) segs[deal.indexOf(s)] = s;
        }
        //for (LineSegment s : segs) {
        //  System.out.println(s);


        return segs;
    }

    //
    public static void main(String[] args) {
        // read the n points from a file
        In in = new In(args[0]);
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();

        // print and draw the line segments
        FastCollinearPoints collinear = new FastCollinearPoints(points);
        for (LineSegment segment : collinear.segments()) {
            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();
    }

    // Point[] points = new Point[8];
    // print and draw the line segments
    //points[0] = new Point(10000, 0);
    //points[1] = new Point(0, 10000);
    //points[2] = new Point(3000, 7000);
    //points[3] = new Point(7000, 3000);
    //points[4] = new Point(20000, 21000);
    //points[5] = new Point(3000, 4000);
    //points[6] = new Point(14000, 15000);
    //points[7] = new Point(6000, 7000);


    //FastCollinearPoints collinear = new FastCollinearPoints(points);
    //System.out.println(collinear.numberOfSegments());
    //System.out.println(collinear.segments());
    //for (LineSegment segment : collinear.segments()) {
    //StdOut.println(segment);
    //segment.draw();
    //}
    //StdDraw.show();
}

//FastCollinearPoints x = new FastCollinearPoints(points);
//System.out.print(x.numberOfSegments());


