import java.util.ArrayList;
import java.util.Arrays;

public class BruteCollinearPoints {
    private int line_seg = 0;
    private LineSegment segs[];
    private ArrayList<LineSegment> ans = new ArrayList<>();

    public BruteCollinearPoints(Point[] points) // finds all line segments containing 4 points
    {
        LineSegment fl;
        if (points == null) throw new IllegalArgumentException();
        for (Point p : points) {
            if (p == null) throw new IllegalArgumentException();
        }
        Arrays.sort(points);
        for (int i = 0; i < points.length; i++) {
            for (int j = i + 1; j < points.length; j++) {
                Double slope1 = points[j].slopeTo(points[i]);
                if (slope1 == Double.NEGATIVE_INFINITY) throw new IllegalArgumentException();
                for (int k = j + 1; k < points.length; k++) {
                    Double slope2 = points[k].slopeTo(points[i]);
                    if (slope2 == Double.NEGATIVE_INFINITY) throw new IllegalArgumentException();
                    for (int l = k + 1; l < points.length; l++) {
                        Double slope3 = points[l].slopeTo(points[i]);
                        if (slope3 == Double.NEGATIVE_INFINITY) throw new IllegalArgumentException();
                        if (slope1.equals(slope2) && slope2.equals(slope3)) {
                            line_seg += 1;
                            fl = new LineSegment(points[i], points[l]);
                            ans.add(fl);
                        }

                    }
                }

            }
        }
    }


    public int numberOfSegments()  // the number of line segments
    {
        return line_seg;
    }

    public LineSegment[] segments()                // the line segments
    {
        segs = new LineSegment[line_seg];
        for (LineSegment s : ans) {
            if (s != null) segs[ans.indexOf(s)] = s;
        }

        //for (LineSegment s : segs) {
        //System.out.println(s);

        return segs;
    }


    public static void main(String[] args) {
        //Scanner in = new Scanner(System.in);
        //int n = in.nextInt();
        Point[] points = new Point[2];
        //int len = points.length;
        //for (int i = 0; i < n; i++) {
        //int x = in.readInt();
        //int y = in.readInt();
        //  int x = in.nextInt();
        //System.out.print(x);
        //int y = in.nextInt();
        //System.out.print(y);
        //points[i] = new Point(x, y);
        //}
        points[0] = new Point(1, 2);
        points[1] = new Point(1, 2);
        //System.out.println(points[0].equals(points[1]));
        BruteCollinearPoints x = new BruteCollinearPoints(points);
        System.out.println(x.numberOfSegments());
        System.out.println(x.segments());

    }
}



