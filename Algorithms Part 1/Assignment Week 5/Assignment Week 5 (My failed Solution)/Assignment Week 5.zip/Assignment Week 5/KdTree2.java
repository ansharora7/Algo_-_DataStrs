import edu.princeton.cs.algs4.Point2D;
import edu.princeton.cs.algs4.RectHV;
import edu.princeton.cs.algs4.Stack;
import edu.princeton.cs.algs4.StdDraw;

public class KdTree2 {
    private Node root;

    //////////////////////////////////////////////////////////////////
    private class Node {
        private Node left, right;
        private int size;
        private Point2D point;
        double key;
        boolean horizontal;

        Node(Point2D point, Double key, int size, boolean horizontal) {
            this.point = point;
            this.size = size;
            this.key = key;
            this.horizontal = horizontal;

        }
    }

    ////////////////////////////////////////////////////////////////////////
    public KdTree2() {
    }

    ////////////////////////////////////////////////////////////////////////////
    public boolean isEmpty() {
        return size() == 0;
    }

    ////////////////////////////////////////////////////////////////////////
    public int size() {
        return (size(root));
    }

    private int size(Node n) {
        if (n == null) return 0;
        return n.size;
    }

    ///////////////////////////////////////////////////////////////////////////
    private boolean curr_horizontal = true;

    public void insert(Point2D p) {
        if (p == null) throw new IllegalArgumentException();
        if (root == null) {
            double key = curr_horizontal ? p.x() : p.y();
            root = insert(root, p, key);
            curr_horizontal = !curr_horizontal;
        }
        else if (!contains(p)) {
            double key = curr_horizontal ? p.x() : p.y();
            root = insert(root, p, key);
            curr_horizontal = !curr_horizontal;
        }
    }

    private Node insert(Node x, Point2D point, Double key) {
        if (x == null) {
            //System.out.print(curr_horizontal ? "horizontal" : "vertical");
            // System.out.println(key);
            //System.out.println(point);
            return new Node(point, key, 1, curr_horizontal);
        }
        double cmp = key - (x.key);
        if (cmp < 0) {
            if (x.left == null) curr_horizontal = !x.horizontal;
            x.left = insert(x.left, point, key);
        }
        else if (cmp >= 0) {
            if (x.right == null) curr_horizontal = !x.horizontal;
            x.right = insert(x.right, point, key);
        }
        // else x.point = point;
        x.size = 1 + size(x.left) + size(x.right);
        return x;
    }

    /////////////////////////////////////////////////////////////////////////////////
    public boolean contains(Point2D p) {
        return (get(p.x(), p) != null || get(p.y(), p) != null);
    }

    private Point2D get(Double key, Point2D p) {
        return get(root, key, p);
    }

    private Point2D get(Node x, Double key, Point2D p) {
        // if (key == null) throw new IllegalArgumentException("calls get() with a null key");
        if (x == null) return null;
        if (x.point.equals(p)) return p;
        double cmp = key - (x.key);
        if (cmp < 0) return get(x.left, key, p);
        else if (cmp >= 0) return get(x.right, key, p);
        else return null;
    }
    ////////////////////////////////////////////////////////////////////////////////

    public void draw() {
        draw(root, 0, 0, 1, 1);
    }

    private void draw(Node x, double x_min, double y_min, double x_max, double y_max) {
        if (x == null) {
            StdDraw.setPenColor(StdDraw.BLACK);
            x.point.draw();
        }

        if (x.horizontal) {
            StdDraw.setPenColor(StdDraw.BLUE);
            RectHV rect = new RectHV(x_min, x.point.y(), x_max, x.point.y());
            rect.draw();
            draw(x.right, x_min, x.point.y(), x_max, y_max);
            draw(x.left, x_min, y_min, x_max, x.point.y());
        }

        if (!x.horizontal) {
            StdDraw.setPenColor(StdDraw.RED);
            RectHV rect = new RectHV(x.point.x(), y_min, x.point.x(), y_max);
            rect.draw();
            draw(x.right, x.point.x(), y_min, x_max, y_max);
            draw(x.left, x_min, y_min, x.point.x(), y_max);
        }
    }

    ////////////////////////////////////////////////////////////////////////////////
    private Stack<Point2D> in_range = new Stack<>();

    public Iterable<Point2D> range(RectHV rect) {
        RectHV curr_rect = new RectHV(0, 0, 1, 1);
        range(rect, root, curr_rect);
        return in_range;
    }

    private void range(RectHV rect, Node curr, RectHV curr_rect) {
        if (curr == null) return;

        if (rect.contains(curr.point)) in_range.push(curr.point);

        if (!rect.intersects(curr_rect)) {
            if (curr.horizontal) {
                double x_min = curr_rect.xmin();
                double x_max = curr_rect.xmax();

                double y_min = curr_rect.ymin();
                double y_max = curr.point.y();

                if (rect.ymax() < y_min) {
                    RectHV left_rect = new RectHV(x_min, y_min, x_max, y_max);
                    range(rect, curr.left, left_rect);
                }

                y_min = curr.point.y();
                y_max = curr_rect.ymax();

                if (rect.ymin() > y_min) {
                    RectHV right_rect = new RectHV(x_min, y_min, x_max, y_max);
                    range(rect, curr.right, right_rect);
                }


            }

            if (!curr.horizontal) {
                double y_min = curr_rect.ymin();
                double y_max = curr_rect.ymax();

                double x_min = curr_rect.xmin();
                double x_max = curr.point.x();

                if (rect.xmax() < x_min) {
                    RectHV left_rect = new RectHV(x_min, y_min, x_max, y_max);
                    range(rect, curr.left, left_rect);
                }

                x_min = curr.point.x();
                x_max = curr_rect.xmax();

                if (rect.xmin() > x_min) {
                    RectHV right_rect = new RectHV(x_min, y_min, x_max, y_max);
                    range(rect, curr.right, right_rect);

                }


            }

        }


        if (rect.intersects(curr_rect)) {
            if (curr.horizontal) {
                double x_min = curr_rect.xmin();
                double x_max = curr_rect.xmax();

                double y_min = curr_rect.ymin();
                double y_max = curr.point.y();

                RectHV left_rect = new RectHV(x_min, y_min, x_max, y_max);
                range(rect, curr.left, left_rect);

                y_min = curr.point.y();
                y_max = curr_rect.ymax();
                RectHV right_rect = new RectHV(x_min, y_min, x_max, y_max);
                range(rect, curr.right, right_rect);


            }

            if (!curr.horizontal) {
                double y_min = curr_rect.ymin();
                double y_max = curr_rect.ymax();

                double x_min = curr_rect.xmin();
                double x_max = curr.point.x();

                RectHV left_rect = new RectHV(x_min, y_min, x_max, y_max);
                range(rect, curr.left, left_rect);

                x_min = curr.point.x();
                x_max = curr_rect.xmax();
                RectHV right_rect = new RectHV(x_min, y_min, x_max, y_max);
                range(rect, curr.right, right_rect);


            }

        }

    }

    //////////////////////////////////////////////////////////////////////////////////////
    public Point2D nearest(Point2D p) {
        double min_dist = p.distanceTo(root.point);
        Point2D nearest_point = root.point;
        //System.out.println(nearest_point + "NEARRSRSRS");
        nearest(p, root, nearest_point, min_dist);
        return final_ans;
    }

    private Point2D final_ans;

    private void nearest(Point2D p, Node x, Point2D nearest_point, double min_dist) {
        // System.out.println(x.point + "POINT");
        // System.out.println("HERE");
        final_ans = nearest_point;
        // System.out.println(final_ans + " NEAREST");
        if (x == null) {
            //   System.out.println("NULL");
            return;
        }
        if (p.distanceTo(x.point) < min_dist) {
            final_ans = x.point;
            //  System.out.println(final_ans + "MAIN");
            min_dist = p.distanceTo(x.point);
        }
        if (x.horizontal) {
            // if (p.y() < x.point.y()) {
            // System.out.print("SECTION 1.1");
            //System.out.println(x.left.point);
            // System.out.println(final_ans + "1.1");
            nearest(p, x.left, final_ans, min_dist);
            // }
            // else if (p.y() > x.point.y()) {
            // System.out.print("SECTION 1.2");
            //System.out.println(x.right.point);
            nearest(p, x.right, final_ans, min_dist);
            // }
            // else final_ans = x.point;
        }

        if (!x.horizontal) {
            // if (p.x() < x.point.x()) {
            // System.out.print("SECTION 2.1");
            //System.out.println(x.left.point);
            //  System.out.println(final_ans + "2.1");
            nearest(p, x.left, final_ans, min_dist);
            // }
            // else if (p.x() > x.point.x()) {
            // System.out.print("SECTION 2.2");
            //System.out.println(x.right.point);
            nearest(p, x.right, final_ans, min_dist);
            // }
            // else final_ans = x.point;
        }
    }

    //////////////////////////////////////////////////////////////////////////////////////////////
    // draw left
    /////////////////////////////////////////////////////////////////////////////////////////////
    public static void main(String[] args) {
        KdTree2 kd = new KdTree2();
        Point2D p0 = new Point2D(0.125, 0.5);
        Point2D p1 = new Point2D(0.375, 0.625);
        Point2D p2 = new Point2D(0.625, 0.875);
        Point2D p3 = new Point2D(0.5, 0.375);
        Point2D near = new Point2D(0.75, 0.75);
        Point2D near2 = new Point2D(0.0, 0.0);
        kd.insert(p0);
        // System.out.println(kd.size());
        kd.insert(p1);
        // System.out.println(kd.size());
        kd.insert(p2);
        // System.out.println(kd.size());
        kd.insert(p3);
        // System.out.println(kd.size());
        kd.insert(near);
        // System.out.println(kd.size());
        kd.insert(near2);
        // System.out.println(kd.contains(p0));
        // System.out.println(kd.contains(p2));
        //System.out.println(kd.size());
        // System.out.println(kd.isEmpty());
        System.out.println(kd.nearest(near));
        //RectHV rect = new RectHV(0.25, 0.125, 0.875, 1.0);
        //System.out.println(kd.range(rect));

    }
}
