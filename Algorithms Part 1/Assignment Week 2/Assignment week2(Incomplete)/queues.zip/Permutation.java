import edu.princeton.cs.algs4.StdIn;

public class Permutation {

    private static RandomizedQueue<String> queue = new RandomizedQueue<>();

    private Permutation(int k, RandomizedQueue queue) {

        for (int i = 0; i < k; i++) {
            System.out.println(queue.dequeue());
        }

    }

    public static void main(String[] args) {
        String input = "";
        while (!StdIn.isEmpty()) {
            input = StdIn.readString();
            queue.enqueue(input);
        }
        int k = Integer.parseInt(args[0]);

        Permutation obj1 = new Permutation(k, queue);
    }
}
