import edu.princeton.cs.algs4.Graph;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.Queue;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.TST;

import java.util.ArrayList;
import java.util.HashMap;

public class BoggleSolver {
    // Initializes the data structure using the given array of strings as the dictionary.
    // (You can assume each word in the dictionary contains only the uppercase letters A through Z.)
    private TST<Integer> dict;
    private HashMap<Integer, Character> chars;
    private Graph graph;

    public BoggleSolver(String[] dictionary) {
        dict = new TST<>();
        for (int i = 0; i < dictionary.length; i++) {
            dict.put(dictionary[i], i);
        }
        // int i = 0;
        // for (i = 0; i < dict.size(); i++) {
        //     System.out.println(dict.contains(dictionary[i]));
        // }
        // System.out.println(i);
    }

    //////////////////////////////////////////////////////////////////////////////////////
    // Making the graph
    private void board(BoggleBoard board) {
        chars = new HashMap<>();
        int rows = board.rows();
        int cols = board.cols();
        graph = new Graph(rows * cols);
        int coord, coord2;
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                coord = i * cols + j;
                chars.put(coord, board.getLetter(i, j));
                // System.out.println(coord + " " + board.getLetter(i, j));

                if (j > 0 && j < cols - 1 && i < rows - 1) {
                    coord2 = i * cols + (j + 1);  // Right
                    graph.addEdge(coord, coord2);

                    coord2 = (i + 1) * cols + j;  // Down
                    graph.addEdge(coord, coord2);

                    coord2 = (i + 1) * cols + (j + 1);  // Right-Diagonal
                    graph.addEdge(coord, coord2);

                    coord2 = (i + 1) * cols + (j - 1);  // Left-Diagonal
                    graph.addEdge(coord, coord2);
                }

                else if (j == 0 && i < rows - 1) {
                    // System.out.println(i + " " + j);
                    coord2 = i * cols + (j + 1);  // Right
                    graph.addEdge(coord, coord2);

                    coord2 = (i + 1) * cols + j;  // Down
                    graph.addEdge(coord, coord2);

                    coord2 = (i + 1) * cols + (j + 1);  // Right-Diagonal
                    graph.addEdge(coord, coord2);
                }

                else if (j == cols - 1 && i < rows - 1) {
                    // System.out.println(i + " " + j);
                    coord2 = (i + 1) * cols + j;  // Down
                    graph.addEdge(coord, coord2);

                    coord2 = (i + 1) * cols + (j - 1);  // Left-Diagonal
                    graph.addEdge(coord, coord2);
                }

                else if (i == rows - 1 && j != cols - 1) {
                    coord2 = i * cols + (j + 1);  // Right
                    graph.addEdge(coord, coord2);
                }
            }
        }
        // for (int i = 0; i < chars.size(); i++) {
        //     for (int k : graph.adj(i))
        //         // System.out.print(chars.get(i) + "---->" + chars.get(k) + "|");
        //         // System.out.println();
        // }
    }

    ///////////////////////////////////////////////////////////////////////////////
    private void DepthFirstSearchPvt(ArrayList<String> words, Graph G, int s, int d) {
        boolean[] marked = new boolean[G.V()];
        String word = "";
        word += chars.get(s);
        if (chars.get(s) == 'Q') word += 'U';

        dfs(graph, s, d, marked, word, words);
    }

    // depth first search from v
    private void dfs(Graph G, int s, int d, boolean[] marked, String word,
                     ArrayList<String> words) {
        if (s == d) {
            // System.out.println(word);
            if (dict.contains(word) && !words.contains(word) && word.length() > 2) words.add(word);
            return;
        }
        marked[s] = true;
        for (int w : G.adj(s)) {
            if (!marked[w]) {
                // System.out.println(chars.get(w) + "  VVVVV");
                // System.out.println(k.size());
                // for (String z : k) System.out.println(z);
                if (chars.get(w) == 'Q') word += "QU";
                else word += (chars.get(w));

                Queue<String> k = (Queue<String>) dict.keysWithPrefix(word);

                if (k.size() == 0) {
                    // System.out.println(word + "  NOT THRO");
                    if (chars.get(w) == 'Q') word = word.substring(0, word.length() - 2);
                    else word = word.substring(0, word.length() - 1);
                    continue;
                }
                // System.out.println(word + " THRO");
                dfs(G, w, d, marked, word, words);

                word = word.substring(0, word.length() - 1);
            }
        }
        marked[s] = false;
    }
    //////////////////////////////////////////////////////////////////////////

    // Returns the set of all valid words in the given Boggle board, as an Iterable.
    public Iterable<String> getAllValidWords(BoggleBoard board) {
        board(board);
        // System.out.println("BOARD DONE");
        ArrayList<String> words = new ArrayList<>();
        for (int i = 0; i < chars.size(); i++) {
            for (int j = 0; j < chars.size(); j++) {
                if (i != j) {
                    DepthFirstSearchPvt(words, graph, i, j);

                }
            }
        }
        return words;
    }

    // Returns the score of the given word if it is in the dictionary, zero otherwise.
    // (You can assume the word contains only the uppercase letters A through Z.)
    public int scoreOf(String word) {
        if (word.length() <= 2) return 0;
        if (dict.contains(word)) {
            if (word.length() == 3 || word.length() == 4) return 1;
            if (word.length() == 5) return 2;
            if (word.length() == 6) return 3;
            if (word.length() == 7) return 5;
            return 11;
        }
        return 0;
    }

    public static void main(String[] args) {
        In in = new In(args[0]);
        String[] dictionary = in.readAllStrings();
        // for (String s : dictionary) System.out.println(s);
        BoggleSolver solver = new BoggleSolver(dictionary);
        BoggleBoard board = new BoggleBoard(args[1]);
        // solver.board(board);
        int score = 0;
        for (String word : solver.getAllValidWords(board)) {
            // StdOut.println(word + " " + solver.scoreOf(word));
            score += solver.scoreOf(word);
        }
        StdOut.println("Score = " + score);
    }


}
