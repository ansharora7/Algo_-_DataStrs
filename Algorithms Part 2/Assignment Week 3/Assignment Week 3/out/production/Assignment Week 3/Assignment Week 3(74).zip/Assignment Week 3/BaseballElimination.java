import edu.princeton.cs.algs4.FlowEdge;
import edu.princeton.cs.algs4.FlowNetwork;
import edu.princeton.cs.algs4.FordFulkerson;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;

public class BaseballElimination {
    private ArrayList<String> teams;
    private ArrayList<String> teams_ahead;
    private final int length;
    private final int[] wins;
    private final int[] losses;
    private final int[] home_remaining;
    private final int[][] away_remaining;
    private FlowNetwork division;
    private FordFulkerson elm_network;


    public BaseballElimination(String filename) {                   // create a baseball division from given filename in format specified below
        In division = new In(filename);
        length = division.readInt();
        teams = new ArrayList<>();
        wins = new int[length];
        losses = new int[length];
        home_remaining = new int[length];
        away_remaining = new int[length][length];
        for (int i = 0; i < length; i++) {
            teams.add(division.readString());
            wins[i] = division.readInt();
            losses[i] = division.readInt();
            home_remaining[i] = division.readInt();

            for (int j = 0; j < length; j++) {
                away_remaining[i][j] = division.readInt();
            }
        }
    }

    public int numberOfTeams() {                        // number of teams
        return teams.size();
    }

    public Iterable<String> teams() {                                // all teams
        return teams;
    }

    public int wins(String team) {                      // number of wins for given team
        return (wins[teams.indexOf(team)]);
    }

    public int losses(String team) {                    // number of losses for given team
        return (losses[teams.indexOf(team)]);
    }

    public int remaining(String team) {                 // number of remaining games for given team
        return (home_remaining[teams.indexOf(team)]);
    }

    public int against(String team1, String team2) {    // number of remaining games between team1 and team2
        int index1 = teams.indexOf(team1);
        int index2 = teams.indexOf(team2);
        return (away_remaining[index1][index2]);

    }

    ///////////////////////////////////////////////////////////////////////////////
    // find first group of vertices
    private int nCr(int n, int r) {
        if (r == 1) return n;
        return n * nCr(n - 1, r - 1) / r;
    }

    /////////////////////////////////////////////////////////////////////////////
    // Trivial elimination
    private boolean trivial_el(String team) {
        teams_ahead = new ArrayList<>();
        int count = 0;
        int max = wins[teams.indexOf(team)] + home_remaining[teams.indexOf(team)];
        for (String t : teams) {
            if (wins[teams.indexOf(t)] > max) {
                teams_ahead.add(t);
                count = 1;
            }
            return count == 1;
        }
        return false;
    }

    ///////////////////////////////////////////////////////////////////////////////
    // create flow network
    private void network(int team_index) {
        int vertices = 2 + nCr(length, 2) + length;
        division = new FlowNetwork(vertices);
        FlowEdge edge;
        int source = vertices - 2;
//        System.out.println(source);
        int target = vertices - 1;
        int i = 0;
        while (i < length) {
            for (int j = 0; j < length; j++) {
//                System.out.println(j + "J");
                for (int k = j + 1; k < length; k++) {
//                    System.out.println(k + "K");
//                    System.out.println(i + "I");
                    edge = new FlowEdge(source, i + length, away_remaining[j][k], 0); // source -> team-matching
                    division.addEdge(edge);

                    edge = new FlowEdge(i + length, j, Double.POSITIVE_INFINITY, 0);   // team-matching -> teams
                    division.addEdge(edge);

                    edge = new FlowEdge(i + length, k, Double.POSITIVE_INFINITY, 0);
                    division.addEdge(edge);

                    i++;
                }
                int cap = Math.abs(wins[team_index] + home_remaining[team_index] - wins[j]); // teams -> target
                edge = new FlowEdge(j, target, cap, 0);
                division.addEdge(edge);
            }
        }
        elm_network = new FordFulkerson(division, source, target);

    }

    public boolean isEliminated(String team) {              // is given team eliminated?
        if (trivial_el(team)) {
//            System.out.println("Trivial");
//            for (String t : teams_ahead) System.out.println(t);
            return true;
        }
        teams_ahead = new ArrayList<>();
        network(teams.indexOf(team));                       // Ford-Fulkerson
        int count = 0;
        int k = 0;
        for (int i = 0; i < length; i++) {
            for (int j = i + 1; j < length; j++) {
                if (!(elm_network.inCut(k + length))) {
                    if (!teams_ahead.contains(teams.get(i))) teams_ahead.add(teams.get(i));
                    count += 1;
                    k++;
                }
            }
        }
//        for (String t : teams_ahead) System.out.println(t);
        return count != nCr(length, 2);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    public Iterable<String> certificateOfElimination(String team) {  // subset R of teams that eliminates given team; null if not eliminated
        if (isEliminated(team)) return teams_ahead;
        return null;
    }

    public static void main(String[] args) {
        BaseballElimination division = new BaseballElimination(args[0]);
        for (String team : division.teams()) {
            if (division.isEliminated(team)) {
                StdOut.print(team + " is eliminated by the subset R = { ");
                for (String t : division.certificateOfElimination(team)) {
                    StdOut.print(t + " ");
                }
                StdOut.println("}");
            } else {
                StdOut.println(team + " is not eliminated");
            }
        }
//        System.out.println(division.nCr(24, 2));
    }
}
