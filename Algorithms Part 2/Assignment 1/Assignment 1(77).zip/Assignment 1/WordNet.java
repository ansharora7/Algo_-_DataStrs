import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.In;

import java.util.HashMap;

public class WordNet {
    // constructor takes the name of the two input files
    // private String synsets, hypernyms;
    private String hypernyms;
    private Digraph graph;
    private SAP sap;
    private HashMap<String, Integer> data = new HashMap<>();

    public WordNet(String synsets, String hypernyms) {
        if (synsets == null || hypernyms == null) {
            throw new IllegalArgumentException();
        }
        // this.synsets = synsets;
        this.hypernyms = hypernyms;
        read_synsets(synsets);
    }

    private void read_synsets(String synsets) {
        In for_synsets = new In(synsets);
        String line;
        while ((line = for_synsets.readLine()) != null) {
            String[] check = line.split(",");
            String[] nouns = check[1].split(" ");
            for (int i = 0; i < nouns.length; i++) {
                data.put(nouns[i], Integer.parseInt(check[0]));
            }
        }
    }

    private void read_hypernyms(String hypernyms) {
        In for_hypernyms = new In(hypernyms);
        graph = new Digraph(data.size());
        while (for_hypernyms.readLine() != null) {
            String[] check = for_hypernyms.readLine().split(",");
            int start = Integer.parseInt(check[0]);

            for (int i = 1; i < check.length; i++) {
                graph.addEdge(Integer.parseInt(check[i]), start);
            }

        }
        sap = new SAP(graph);
    }

    // returns all WordNet nouns
    public Iterable<String> nouns() {
        return data.keySet();
    }


    // is the word a WordNet noun?
    public boolean isNoun(String word) {
        if (word == null) throw new IllegalArgumentException();
        return (data.containsKey(word));
    }

    // distance between nounA and nounB (defined below)
    public int distance(String nounA, String nounB) {
        read_hypernyms(hypernyms);
        if (nounA == null || nounB == null) throw new IllegalArgumentException();
        if (!isNoun(nounA) || !isNoun(nounB)) throw new IllegalArgumentException();
        int a = data.get(nounA);
        int b = data.get(nounB);
        return (sap.length(a, b));
    }

    // a synset (second field of synsets.txt) that is the common ancestor of nounA and nounB
    // in a shortest ancestral path (defined below)
    public String sap(String nounA, String nounB) {
        read_hypernyms(hypernyms);
        if (nounA == null || nounB == null) throw new IllegalArgumentException();
        int a = data.get(nounA);
        int b = data.get(nounB);
        return "AB";
        // return (sap.ancestor(data.get(nounA), data.get(nounB)));
    }

    // do unit testing of this class
    public static void main(String[] args) {
    }
}
